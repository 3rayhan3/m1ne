import React, { useEffect, useState } from 'react';

function Home() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    alert('Welcome! Click the button to increase the count.');
  }, []);

  useEffect(() => {
    console.log(`Count is now: ${count}`);
  }, [count]);

  return (
    <div style={{ padding: '20px' }}>
      <h2>Home Page</h2>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increase Count</button>
    </div>
  );
}

export default Home;
