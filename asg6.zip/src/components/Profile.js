import React, { useState } from 'react';

function Profile() {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <div style={{ padding: '20px' }}>
      <h2>Profile Page</h2>
      <button onClick={() => setShowDetails(!showDetails)}>
        {showDetails ? 'Hide' : 'Show'} Details
      </button>
      {showDetails && (
        <p style={{ marginTop: '10px' }}>
          Hello! These are the additional profile details you can now see.
        </p>
      )}
    </div>
  );
}

export default Profile;
