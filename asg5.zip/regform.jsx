import React, { useState } from 'react'; import './RegistrationForm.css';

const RegistrationForm = () => { const [formData, setFormData] = useState({ fullName: '', email: '', password: '', confirmPassword: '', gender: '', country: '', terms: false, });

const [errors, setErrors] = useState({}); const [submitted, setSubmitted] = useState(false); const [success, setSuccess] = useState(false);

const handleChange = (e) => { const { name, value, type, checked } = e.target; setFormData((prevData) => ({ ...prevData, [name]: type === 'checkbox' ? checked : value, })); };

const validate = () => { const newErrors = {}; if (!formData.fullName.trim()) newErrors.fullName = 'Full Name is required'; if (!formData.email) newErrors.email = 'Email is required'; if (!formData.password) newErrors.password = 'Password is required'; if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match'; if (!formData.gender) newErrors.gender = 'Gender is required'; if (!formData.country) newErrors.country = 'Country is required'; if (!formData.terms) newErrors.terms = 'You must agree to the terms'; return newErrors; };

const handleSubmit = (e) => { e.preventDefault(); const validationErrors = validate(); setErrors(validationErrors); setSubmitted(true); if (Object.keys(validationErrors).length === 0) { console.log('Form Data:', formData); setSuccess(true); setFormData({ fullName: '', email: '', password: '', confirmPassword: '', gender: '', country: '', terms: false, }); } else { setSuccess(false); } };

return ( <div className="form-container"> <form onSubmit={handleSubmit}> <h2>Registration Form</h2>

<label>Full Name</label>
    <input type="text" name="fullName" value={formData.fullName} onChange={handleChange} />
    {submitted && errors.fullName && <p className="error">{errors.fullName}</p>}

    <label>Email</label>
    <input type="email" name="email" value={formData.email} onChange={handleChange} />
    {submitted && errors.email && <p className="error">{errors.email}</p>}

    <label>Password</label>
    <input type="password" name="password" value={formData.password} onChange={handleChange} />
    {submitted && errors.password && <p className="error">{errors.password}</p>}

    <label>Confirm Password</label>
    <input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} />
    {submitted && errors.confirmPassword && <p className="error">{errors.confirmPassword}</p>}

    <label>Gender</label>
    <div>
      <label><input type="radio" name="gender" value="Male" checked={formData.gender === 'Male'} onChange={handleChange} /> Male</label>
      <label><input type="radio" name="gender" value="Female" checked={formData.gender === 'Female'} onChange={handleChange} /> Female</label>
    </div>
    {submitted && errors.gender && <p className="error">{errors.gender}</p>}

    <label>Country</label>
    <select name="country" value={formData.country} onChange={handleChange}>
      <option value="">Select</option>
      <option value="India">India</option>
      <option value="USA">USA</option>
      <option value="UK">UK</option>
    </select>
    {submitted && errors.country && <p className="error">{errors.country}</p>}

    <label>
      <input type="checkbox" name="terms" checked={formData.terms} onChange={handleChange} /> I agree to the terms
    </label>
    {submitted && errors.terms && <p className="error">{errors.terms}</p>}

    <button type="submit">Submit</button>
    {success && <p className="success">Form submitted successfully!</p>}
  </form>
</div>

); };

export default RegistrationForm;